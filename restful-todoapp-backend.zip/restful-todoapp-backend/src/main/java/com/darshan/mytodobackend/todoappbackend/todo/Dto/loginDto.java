package com.darshan.mytodobackend.todoappbackend.todo.Dto;

import lombok.Data;

@Data
public class loginDto {

    private String username;
    private String password;
}