insert into todo (id, description, done, target_date,username)
values (10001, 'Learn Java Spring Framework', false, CURRENT_DATE(), 'darshan');

insert into todo (id, description, done, target_date,username)
values (10002, 'Learn Fullstack Devlopement', false, CURRENT_DATE(), 'darshan');

insert into todo (id, description, done, target_date,username)
values (10003, 'Learn React and Next Js', false, CURRENT_DATE(), 'darshan');