package com.darshan.mytodobackend.todoappbackend.tests;

import com.darshan.mytodobackend.todoappbackend.pages.AddTodoPage;
import com.darshan.mytodobackend.todoappbackend.pages.ListTodosPage;
import com.darshan.mytodobackend.todoappbackend.pages.LoginPage;
import com.darshan.mytodobackend.todoappbackend.pages.WelcomePage;
import com.darshan.mytodobackend.todoappbackend.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AddNewTodoButtonTest extends BaseTest{

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][]{
                {ConfigReader.get("username"), ConfigReader.get("password")}
        };
    }

    @Test(dataProvider = "loginData")
    public void testAddNewTodoNavigation(String username, String password) {

        // 1) Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(username, password);

        // 2) Welcome page → click "here"
        WelcomePage welcomePage = new WelcomePage(driver);
        welcomePage.goToTodos();

        // 3) الآن في list-todos
        ListTodosPage listTodosPage = new ListTodosPage(driver);
        listTodosPage.waitForPageToLoad();

        // 4) اضغط Add New Todo
        listTodosPage.clickAddNewTodo();

        // 5) الآن نصل لصفحة /list-todos/-1
        AddTodoPage addTodoPage = new AddTodoPage(driver);
        Assert.assertTrue(addTodoPage.isAddTodoPageDisplayed(),
                "Add Todo Page did not open!");

        // 6) Verify URL
        Assert.assertTrue(driver.getCurrentUrl().contains("/list-todos/-1"),
                "URL is incorrect after clicking Add New Todo!");
    }

//    @Test
//    public void testAddNewTodoNavigation() {
//
//        // 1) Login
//        LoginPage loginPage = new LoginPage(driver);
//        loginPage.login(ConfigReader.get("username"), ConfigReader.get("password"));
//
//        // 2) Welcome page → click "here"
//        WelcomePage welcomePage = new WelcomePage(driver);
//        welcomePage.goToTodos();
//
//        // 3) الآن في list-todos
//        ListTodosPage listTodosPage = new ListTodosPage(driver);
//        listTodosPage.waitForPageToLoad();
//
//        // 4) اضغط Add New Todo
//        listTodosPage.clickAddNewTodo();
//
//        // 5) الآن نصل لصفحة /list-todos/-1
//        AddTodoPage addTodoPage = new AddTodoPage(driver);
//        Assert.assertTrue(addTodoPage.isAddTodoPageDisplayed());
//
//        // 6) Verify URL
//        Assert.assertTrue(driver.getCurrentUrl().contains("/list-todos/-1"));
//    }



}
