
const Error404 = () => {
  return (
    <div>
        <h1>404 NOT FOUND, WE ARE WORKING ON IT</h1>
    </div>
  )
}

export default Error404