const LogOut = () => {
    return (
        <div className="container text-center mt-auto py-3 bg-light">
            <h1>  You are Logged Out </h1>
        </div>
    )
}

export default LogOut